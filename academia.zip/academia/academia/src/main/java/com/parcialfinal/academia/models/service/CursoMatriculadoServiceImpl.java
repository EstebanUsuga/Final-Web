package com.parcialfinal.academia.models.service;

import com.parcialfinal.academia.models.dao.CursoMatriculadoRepository;
import com.parcialfinal.academia.models.entity.CursoMatriculado;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class CursoMatriculadoServiceImpl implements CursoMatriculadoService{

    private final CursoMatriculadoRepository cursoMatriculadoRepository;

    @Override
    @Transactional(readOnly = true)
    public List<CursoMatriculado> obtenerCursosMatriculados() {
        return cursoMatriculadoRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<CursoMatriculado> obtenerCursoMatriculadoPorId(Long id) {
        return cursoMatriculadoRepository.findById(id);
    }

    @Override
    @Transactional
    public void guardar(CursoMatriculado cursoMatriculado) {
        cursoMatriculadoRepository.save(cursoMatriculado);
    }

    @Override
    @Transactional
    public void eliminarCursoMatriculadoPorId(Long id) {
        cursoMatriculadoRepository.deleteById(id);
    }
}
