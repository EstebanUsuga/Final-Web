package com.parcialfinal.academia.controller;

import com.parcialfinal.academia.models.entity.Estudiante;
import com.parcialfinal.academia.models.service.CursoService;
import com.parcialfinal.academia.models.service.EstudianteService;
import com.parcialfinal.academia.models.service.ProgramaAcademicoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/academia")
@RequiredArgsConstructor
@SessionAttributes("estudiantes")
public class MatriculaController {

    private final EstudianteService estudianteService;
    private final ProgramaAcademicoService programaAcademicoService;
    private final CursoService cursoService;

    @GetMapping("/matriculanueva")
    public String nuevoEstudianteForm(Model model) {
        model.addAttribute("accion", "Crear");
        model.addAttribute("cursos", cursoService.obtenerCursosPorEstudiante();
        return "vistas/matricula/matricular_materias";
    }

    @PostMapping("/matriculaguardar")
    public String guardarEstudiante(@Valid @ModelAttribute Estudiante estudiante, BindingResult result,
                                    Model model, RedirectAttributes flash) {
        String accion = (estudiante.getId() == null) ? "Guardar" : "Modificar";

        if (result.hasErrors()) {
            model.addAttribute("titulo", accion + " Estudiante");
            model.addAttribute("accion", accion);
            model.addAttribute("info", "Corrija los campos del formulario");
            return "vistas/estudiante/formulario_estudiante";
        }

        estudianteService.guardar(estudiante);

        flash.addFlashAttribute("success",
                "El estudiante fue " + (estudiante.getId() == null ? "agregado" : "modificado") + " con éxito");
        return "redirect:/academia/estudianteslistar";
    }
}
