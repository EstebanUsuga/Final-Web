package com.parcialfinal.academia.models.service;


import com.parcialfinal.academia.models.dao.CursoRepository;
import com.parcialfinal.academia.models.dao.EstudianteRepository;
import com.parcialfinal.academia.models.entity.Curso;
import com.parcialfinal.academia.models.entity.Estudiante;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class CursoServiceImpl implements CursoService{

    private final CursoRepository cursoRepository;
    private final EstudianteRepository estudianteRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Curso> obtenerCursos() {
        return cursoRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Curso> obtenerCursoPorId(Long id) {
        return cursoRepository.findById(id);
    }

    @Override
    @Transactional
    public void guardar(Curso curso) {
        cursoRepository.save(curso);
    }

    @Override
    @Transactional
    public void eliminarCursoPorId(Long id) {
        cursoRepository.deleteById(id);
    }

    @Override
    public List<Curso> obtenerCursosPorEstudiante(Long programaId, List<Long> asignaturasCursadasIds, int semestre) {
        return cursoRepository.obtenerCursosPorEstudiante(programaId, asignaturasCursadasIds, semestre);
    }


}
