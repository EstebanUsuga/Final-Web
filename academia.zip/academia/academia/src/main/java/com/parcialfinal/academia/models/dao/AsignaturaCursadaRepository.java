package com.parcialfinal.academia.models.dao;

import com.parcialfinal.academia.models.entity.AsignaturaCursada;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AsignaturaCursadaRepository extends JpaRepository<AsignaturaCursada, Long> {
    List<AsignaturaCursada> findByEstudianteId(Long estudianteId);
    List<AsignaturaCursada> findByAsignaturaId(Long asignaturaId);
}
