package services;

import models.PlanEstudio;

import java.util.List;
import java.util.Optional;

public interface PlanEstudioService {

    List<PlanEstudio> obtenerPlanesEstudio();
    Optional<PlanEstudio> obtenerPlanEstudioPorId(Long id);
    void guardar(PlanEstudio planEstudio);
    void eliminarPlanEstudioPorId(Long id);


}
