package services;

import models.ProgramaAcademico;

import java.util.List;
import java.util.Optional;

public interface ProgramaAcademicoService {

    List<ProgramaAcademico> obtenerProgramasAcademicos();
    Optional<ProgramaAcademico> obtenerProgramaAcademicoPorId(Long id);
    void guardar(ProgramaAcademico programaAcademico);
    void eliminarProgramaAcademicoPorId(Long id);
}
