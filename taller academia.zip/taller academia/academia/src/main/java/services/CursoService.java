package services;

import models.Curso;

import java.util.List;
import java.util.Optional;

public interface CursoService {

    List<Curso> obtenerCursos();
    Optional<Curso> obtenerCursoPorId(Long id);
    void guardar(Curso curso);
    void eliminarCursoPorId(Long id);
}
