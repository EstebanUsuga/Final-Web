package services;


import lombok.RequiredArgsConstructor;
import models.Curso;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import repository.CursoRepository;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class CursoServiceImpl implements CursoService{

    private final CursoRepository cursoRepository;

    @Override
    @Transactional(readOnly = true)
    public List<Curso> obtenerCursos() {
        return cursoRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Curso> obtenerCursoPorId(Long id) {
        return cursoRepository.findById(id);
    }

    @Override
    @Transactional
    public void guardar(Curso curso) {
        cursoRepository.save(curso);
    }

    @Override
    @Transactional
    public void eliminarCursoPorId(Long id) {
        cursoRepository.deleteById(id);
    }
}
