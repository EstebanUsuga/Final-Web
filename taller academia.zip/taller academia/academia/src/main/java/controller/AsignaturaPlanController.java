package controller;

public class AsignaturaPlanController {
}
