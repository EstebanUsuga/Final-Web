package controller;

public class CursoMatriculadoController {
}
