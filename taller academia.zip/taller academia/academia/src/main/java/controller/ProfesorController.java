package controller;

public class ProfesorController {
}
