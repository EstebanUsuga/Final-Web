package models;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Profesor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50, nullable = false)
    @NotEmpty
    private String apellidos;

    @Column(length = 50, nullable = false)
    @NotEmpty
    private String nombres;

    @Column(length = 80, nullable = false)
    @NotEmpty
    private String especializacion;

    @Column(length = 20, nullable = false)
    @NotEmpty
    private String departamento;
}
