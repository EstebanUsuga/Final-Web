package repository;

import models.PlanEstudio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PlanEstudioRepository extends JpaRepository<PlanEstudio, Long> {
    List<PlanEstudio> findByNombre(String nombre);

}
