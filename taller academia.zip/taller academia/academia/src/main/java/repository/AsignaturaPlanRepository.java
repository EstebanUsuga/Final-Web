package repository;

import models.Asignatura;
import models.AsignaturaPlan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AsignaturaPlanRepository extends JpaRepository<AsignaturaPlan, Long> {
    List<AsignaturaPlan> findByPlanId(Long planId);
    List<AsignaturaPlan> findBySemestreNivel(Integer semestreNivel);
}
